/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.edu.principal.kitty1;

/**
 *
 * @author User
 */
public class Kitty1 {

    public static void main(String[] args) {
       TelaPrincipal2 tela = new TelaPrincipal2();
       tela.setVisible(true);
       
    }
}
