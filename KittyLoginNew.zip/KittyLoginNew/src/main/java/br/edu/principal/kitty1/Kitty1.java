/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.edu.principal.kitty1;

import br.com.login.view.LoginView;

/**
 *
 * @author User
 */
public class Kitty1 {

    public static void main(String[] args) {
       LoginView tela = new LoginView();
       tela.setVisible(true);
       
    }
}
