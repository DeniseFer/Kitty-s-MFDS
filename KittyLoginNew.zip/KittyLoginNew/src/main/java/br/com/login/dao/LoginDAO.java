/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.login.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDAO {

public void cadastrarUsuario(String nome, String endereco, String senha, String confi_senha) throws SQLException{    
      Connection conexao = new Conexao().getConnection();
      String sql = "INSERT INTO kitty_login (nome, endereco, senha, confi_senha) VALUES ('"+nome+"','"+endereco+"','"+senha+"','"+confi_senha+"')";
      System.out.println(sql);
      PreparedStatement statement = conexao.prepareStatement(sql);
      statement.execute();
      conexao.close();
}

public void login(String nome, String senha) throws SQLException {
 Connection conexao = new Conexao().getConnection();
      String sql = "SELECT nome,senha FROM kitty_login WHERE nome = '"+nome+"' AND senha = '"+senha+"'";
      System.out.println(sql);
      PreparedStatement statement = conexao.prepareStatement(sql);
      ResultSet rs = statement.executeQuery();

      if (rs.next()){

      System.out.println("Possui");
} else {
       System.out.println("Não possui");

}
      conexao.close();

}
}
