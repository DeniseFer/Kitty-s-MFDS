/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.login.model;

/**
 *
 * @author u
 */
public class Login {
private String nome, senha, endereco, confi_senha;

    public Login(String nome, String senha) {
        this.nome = nome;
        this.senha = senha;
    }

public void cadastrar(String nome, String endereco, String senha, String confi_senha){

this.nome = nome;
this.endereco = endereco;
this.senha = senha;
this.confi_senha = confi_senha;

}

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getConfi_senha() {
        return confi_senha;
    }

    public void setConfi_senha(String confi_senha) {
        this.confi_senha = confi_senha;
    }

}
